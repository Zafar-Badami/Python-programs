'''
Complete the definitions of the following functions using only a single line of code.
'''

def reverse_list(integers):
    '''
    Reverse the list (in-place)
    '''
    pass

def minimum(integers):
    '''
    Find and return the lowest number in the list
    '''
    pass

def sum_list(integers):
    '''
    Return the sum of all numbers
    '''
    pass
